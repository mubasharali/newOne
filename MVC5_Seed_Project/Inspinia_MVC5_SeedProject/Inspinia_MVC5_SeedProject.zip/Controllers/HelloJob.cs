﻿namespace Inspinia_MVC5_SeedProject.Controllers
{
    internal class HelloJob
    {
    }
}